var commonFunctionality = {
  passwordEyeKey: function (inputField, eyeIcone) {
    inputField.keydown(function () {
      if (inputField.val() != '') {
        eyeIcone.removeClass('d-none');
      } else {
        eyeIcone.addClass('d-none');
      }
    });
  },
  passwordShowHide: function (inputType, action) {
    action.toggleClass('blueish');
    if (inputType.attr('type') == 'password') {
      inputType.prop('type', 'text');
    } else {
      inputType.prop('type', 'password');
    }
  },

  hideErrorMsg: function () {
    $('.errorMsg').addClass('d-none');
    $('.type-input-field').removeClass('error-line');
  },
  hideError: function () {
    $('.errorMsg').hide();
    $('.type-input-field').removeClass('error-line');
  },
  inputCorrectCheck: function (id) {
    $('#' + id).siblings('.indicator-icons').removeClass('d-none');
  },
  formLabelTogalOnPageLoad: function () {
    $('.form-input').each(function () {
      if ($(this).val() !== '') {
        $(this).siblings('.placeholder-label').addClass('focus-input');
        $(this).siblings('.cty-code').removeClass('d-none');
      }
    });
  },

  validateAmount: function (amount, pending) {
    var error = {
      amount: ""
    };
    error.amount = (amount < 100) ? "The minimum you need to invest is ₹100/-" : error.amount;
    error.amount = (amount % 100 != 0) ? "Please enter an amount in multiples of ₹100/-" : error.amount;
    error.amount = amount > pending ? "Amount entered is more than what's required" : error.amount;
    error.amount = amount > 50000 ? "The maximum you can invest in an investee is ₹50,000/-" : error.amount;
    return error;
  },
  validateAgainstCart: function (loanKey, txnAmount) {
    var cartItems = JSON.parse(localStorage.getItem("cartItems"));
    var validate = {
      error: "",
      warning: ""
    };
    if (cartItems) {
      cartItems.forEach(function (item) {
        if (item.loanCode === loanKey && item.amountInvested === Number(txnAmount)) {
          validate.warning = 'You already have added this amount!';
        } else if (item.loanCode === loanKey && item.amountInvested !== Number(txnAmount)) {
          validate.warning = 'This will override the previous selected amount!';
        }
      });
    }
    return validate;
  },

  pagination: function (totalItems, currentPage, pageSize, maxPages) {
    var totalPages = Math.ceil(totalItems / pageSize);
    if (currentPage < 1) {
      currentPage = 1;
    } else if (currentPage > totalPages) {
      currentPage = totalPages;
    }

    var startPage, endPage;
    if (totalPages <= maxPages) {
      startPage = 1;
      endPage = totalPages;
    } else {
      var maxPagesBeforeCurrentPage = Math.floor(maxPages / 2);
      var maxPagesAfterCurrentPage = Math.ceil(maxPages / 2) - 1;
      if (currentPage <= maxPagesBeforeCurrentPage) {
        startPage = 1;
        endPage = maxPages;
      } else if (currentPage + maxPagesAfterCurrentPage >= totalPages) {
        startPage = totalPages - maxPages + 1;
        endPage = totalPages;
      } else {
        startPage = currentPage - maxPagesBeforeCurrentPage;
        endPage = currentPage + maxPagesAfterCurrentPage;
      }
    }

    var startIndex = (currentPage - 1) * pageSize;
    var endIndex = Math.min(startIndex + pageSize - 1, totalItems - 1);

    var pages = [];
    for (index = startPage; index <= endPage; index++)
      pages.push(index);

    return {
      totalItems: totalItems,
      currentPage: currentPage,
      pageSize: pageSize,
      totalPages: totalPages,
      startPage: startPage,
      endPage: endPage,
      startIndex: startIndex,
      endIndex: endIndex,
      pages: pages
    };
  },
  urlParamsObj: function () {
    var uri = window.location.search;
    if (uri.indexOf("?") > -1) {
      var paramsArray = uri.substring(uri.indexOf("?") + 1).split('&'),
        params = {},
        i = 0,
        x;
      for (; i < paramsArray.length; i++) {
        x = paramsArray[i].toString().split('=');
        params[x[0]] = params[x[0]] && params[x[0]].length ? decodeURIComponent(params[x[0]]) + ',' + x[1] : decodeURIComponent(x[1]);
      }
      return params;
    }
    return {};
  },
  createSearchUri: function (obj) {
    var template = '';
    Object.keys(obj).map(function (param) {
      obj[param].split(",").forEach(function (el) {
        template += param + '=' + el + '&';
      });
    });
    return template;
  },
  isInViewport: function (elem) {
    var distance = elem.getBoundingClientRect();
    return (
      distance.top >= 0 &&
      distance.left >= 0 &&
      distance.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
      distance.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
  },
  passwordPopover: function (password) {
    $('[data-toggle="popover"]').popover('hide');
    var popoverText = '';
    popoverText += (password.length < 8 || password.length > 16) ? '<p class="popup-check"> <i class="fas fa-check"></i> 8-16 characters</p>' : '<p class="popup-check error"> <i class="fas fa-check"></i> 8-16 characters</p>';
    popoverText += !/[a-z]/g.test(password) ? '<p class="popup-check"> <i class="fas fa-check"></i> One lower case letter</p>' : '<p class="popup-check error"> <i class="fas fa-check"></i> One lower case letter</p>';
    popoverText += !/[A-Z]/g.test(password) ? '<p class="popup-check"> <i class="fas fa-check"></i> One upper case letter</p>' : '<p class="popup-check error"> <i class="fas fa-check"></i> One upper case letter</p>';
    popoverText += !/[0-9]/g.test(password) ? '<p class="popup-check"> <i class="fas fa-check"></i> One numeric character</p>' : '<p class="popup-check error"> <i class="fas fa-check"></i> One numeric character</p>';
    //popoverText += !/[!"#$%&'()*+,-./:;<=>?@^[_`{|}~]/g.test(password) ? '<p class="popup-check"> <i class="fas fa-check"></i> One special character</p>' : '<p class="popup-check error"> <i class="fas fa-check"></i> One special character</p>';
    $("#error-popup").attr("data-content", popoverText);
  },
  dateConvert: function (dataSelector) {
    var actualDate = new Date(dataSelector);
    var stringDate = actualDate.toString('dd-mm-yy');
    var formatedDate = (stringDate.split(' ')[2] + '-' + converMonthInNumber(stringDate.split(' ')[1]) + '-' + stringDate.split(' ')[3]);

    function converMonthInNumber(val) {
      switch (val) {
        case 'Jan':
          return '01'
          break;

        case 'Feb':
          return '02'
          break;

        case 'Mar':
          return '03'
          break;

        case 'Apr':
          return '04'
          break;

        case 'May':
          return '05'
          break;

        case 'Jun':
          return '06'
          break;

        case 'Jul':
          return '07'
          break;

        case 'Aug':
          return '08'
          break;

        case 'Sep':
          return '09'
          break;

        case 'Oct':
          return '10'
          break;

        case 'Nov':
          return '11'
          break;

        case 'Dec':
          return '12'
          break;
      }
    }
    return formatedDate;
  },
  scrollToError: function () {
    var scrollEorro = $('.errorMsg:visible').first();
    if (scrollEorro.length != 0) {
      $('html, body').animate({
        scrollTop: scrollEorro.offset().top - 200
      }, 500);
    }
  },
  datepickerCalenderOpen: function (selector) {
    selector.siblings('.datepicker').trigger('focus');
  }, 

  checkboxCustomStyleClass : function (currentElm) {
    if (currentElm[0].checked) {
      currentElm.siblings('.custom-checkbox').find('i').addClass('checked');
    } else {
      currentElm.siblings('.custom-checkbox').find('i').removeClass('checked');
    }
  }
};

$(document).ready(function () {

  // hide popover
  $('html').on('click', function (e) {
    if (typeof $(e.target).data('original-title') == 'undefined' && !$(e.target).parents().is('.popover.in')) {
      $('[data-original-title]').popover('hide');
    }
  });
  
  $(document).on("click", "#copy-link", function () {
	  $(".copy-link-input")[0].select();
	  document.execCommand("copy");
	  $(".success").removeClass("d-none");
  });

  $(document).on("click", ".close", function () {
	  $(".success").addClass("d-none");
  });
  
});