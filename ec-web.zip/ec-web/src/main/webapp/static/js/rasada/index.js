var indexPage = (function () {
  function init() {
    var $contact = $('#form-submit');
	var $errorMessage = $('.errorMsg');
	var validate = {
		form: function() {
			var isValidated = true;
        	$errorMessage.hide();

			$('#name').val($.trim($('#name').val()));
        	$('#email').val($.trim($('#email').val()));
			$('#subject').val($.trim($('#subject').val()));
			$('#message').val($.trim($('#message').val()));

			if($('#name').val() == ""){
	            $errorMessage.show().text('Please enter your name');
	            isValidated = false;
	        } else if (!/^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]{2,})+$/.test($('#email').val())) {
	    	    $errorMessage.show().text('Please enter your valid email address to continue');
	            isValidated = false;
			} else if ($('#subject').val() == "") {
	            $errorMessage.show().text('Please enter subject');
	            isValidated = false;
	        } else if ($('#message').val() == "") {
	            $errorMessage.show().text('Please enter your message');
	            isValidated = false;
	        }
			return isValidated;
		}	
	};
	$contact.click(function(ev) {
		ev.preventDefault();
		$errorMessage.hide();
		if (validate.form()) {
			var contactData = new FormData($('#contact')[0]);
			$('#form-submit').attr('disabled', true);
			$.ajax({
				url: $('#contact').attr("action"),
				method: "POST",
				data: contactData,
				contentType: false,
				processData: false,
			}).done(function(response) {
				$('.contact-form').html("Thanks for contacting us. We will get back to you shortly");
			}).fail(function(error) {
				$('#form-submit').attr('disabled', false);
				$errorMessage.show().text("Oops!! Something went worng, Please try again.");
			});
		}
	});
  };
  return {
    init: init
  };
})()