var signUpForm = (function () {
  function init() {
    var loader = $("#loader-overlay");
    var otptiming;
    var isResendRequested = false;
    var isResendRequestExpired = false;
    var loginRelativePath = $('#login-relative-path').attr('href');
    $errorMessage = $('.errorMsg');
    $('#input-mobile').intlTelInput({
      utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/16.0.3/js/utils.js",
      initialCountry: "auto",
      separateDialCode: true,
      // customPlaceholder: function (selectedCountryPlaceholder, selectedCountryData) {
      //   return "e.g. " + selectedCountryPlaceholder;
      // },
      geoIpLookup: function (success, failure) {

        $.get("https://ipinfo.io", function () { }, "jsonp").always(function (resp) {
          var countryCode = (resp && resp.country) ? resp.country : "";
          success(countryCode);
        });
      },
    });

    var registrationPageFun = {
      validation: function (isValidNumber) {
        var isValidated = true;
        commonFunctionality.hideErrorMsg();
        $('#input-email').val($.trim($('#input-email').val()));
        $('#input-mobile').val($('#input-mobile').val().replace(/\s/g, ""));
        $('.type-input-field').each(function () {
    	  if (!isValidNumber && !/^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]{2,})+$/.test($('#input-email').val())) {
    	    $errorMessage.removeClass('d-none').text('Please enter your valid mobile number & email address to continue registering');
            isValidated = false;
          } else if($('#input-mobile').val()[0] == 0){
            $('#input-mobile').addClass('error-line');
            //$('#input-mobile').parents('.iti--separate-dial-code').siblings('.errorMsg').removeClass('d-none').text('Mobile number is not valid');
            $errorMessage.removeClass('d-none').text('Please enter a valid mobile number');
            isValidated = false;
          } else if (!isValidNumber) {
            $('#input-mobile').addClass('error-line');
            //$('#input-mobile').parents('.iti--separate-dial-code').siblings('.errorMsg').removeClass('d-none').text('Mobile number is not valid');
            $errorMessage.removeClass('d-none').text('Please enter a valid mobile number');
            isValidated = false;
          } else if (!/^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]{2,})+$/.test($('#input-email').val())) {
            $('#input-email').addClass('error-line');
            //$('#input-email').siblings('.errorMsg').removeClass('d-none').text('Email address is not valid');
            $errorMessage.removeClass('d-none').text('Please enter a valid email address');
            isValidated = false;
          }
        });
        commonFunctionality.scrollToError();
        return isValidated;
      },

      lookupEmail: function (email) {
        commonFunctionality.hideErrorMsg();
        var isLookup;
        $.ajax({
          async: false,
          url: $('.lookup-path').attr('href') + "?email=" + encodeURIComponent(email.val()),
          method: "GET",
          contentType: "application/json",
          dataType: "json",
          success: function (successMsg) {
            isLookup = true;
          },
          error: function (errorResponse) {
            if (errorResponse.responseJSON.messages) {
              email.addClass('error-line');
              //email.siblings('.errorMsg').removeClass('d-none').text('Email address is already being used');
              $errorMessage.removeClass('d-none').html('The email address entered is already in use. Kindly proceed to <a class="link-primary" href="' + loginRelativePath + '">login</a>');
              isLookup = false;
            }
          }
        });
        return isLookup;
      },

      lookupMobile: function (mobile) {
        commonFunctionality.hideErrorMsg();
        var isLookup;
        $.ajax({
          async: false,
          url: $('.lookup-path').attr('href') + "?mobileNumber=" + mobile.val(),
          method: "GET",
          contentType: "application/json",
          dataType: "json",
          success: function (successMsg) {
            isLookup = true;
          },
          error: function (errorResponse) {
            if (errorResponse.responseJSON.messages) {
              $('#input-mobile').addClass('error-line');
              //$('#input-mobile').parents('.iti--separate-dial-code').siblings('.errorMsg').removeClass('d-none').text('Mobile number is already being used');
              $errorMessage.removeClass('d-none').html('The mobile number entered is already in use. Kindly proceed to <a class="link-primary" href="' + loginRelativePath + '">login</a>');
              isLookup = false;
            }
          }
        });
        return isLookup;
      },

      handleLoader: function (loaderIsOne) {
        if (loaderIsOne == true) {
          loader.removeClass('d-none');
        } else {
          loader.addClass('d-none');
        }
      },

      sendOTPtoMobileNumber: function (resend) {
        var mobileOtp = new FormData();
        mobileOtp.append('mobileNumber', $('#second-mobile-number').val());
        mobileOtp.append('_csrf', $("meta[name=_csrf]").attr("content"));
        $.ajax({
          url: $('.otp').data('send'),
          type: 'POST',
          data: mobileOtp,
          processData: false,
          contentType: false,
          success: function (successFlg) {
            loderIsOn = false;
            if (!resend) {
              $('.form-section').removeClass('active');
              $('.opt-section').addClass('active');
              $('.otp-info span').html("+" + $('#second-mobile-number').val());
              registrationPageFun.handleLoader(false);
            }
            registrationPageFun.OTPtimer();
          }
        });
      },

      OTPtimer: function () {
        var timer = 60;
        otptiming = setInterval(function () {
          countingTime();
        }, 1000);

        function countingTime() {
          $('#resend-otp').addClass('d-none');
          $('#verification-code').attr('disabled', false);
          timer = timer - 1;
          if (timer != -1) {
            registrationPageFun.handleLoader(false);
            $('.timer-clock span').text(timer);
          } else {
            clearInterval(otptiming);
            $('#verification-code').attr('disabled', true);
            $('#resend-otp').removeClass('d-none');
            $('#verification-code').val('');
            if (isResendRequested) {
            	isResendRequestExpired = true;
            	$errorMessage.removeClass('d-none').html("Oops, looks like the network is bad. Don’t worry, just click on <a class='link-primary' href='#' id='direct-signup'>Next</a>");
            	$('#go-back').hide();
            }
          }
        }
      },

      OTPVerifyFun: function () {
        var mobileOtp = new FormData();
        mobileOtp.append('mobileNumber', $('#second-mobile-number').val());
        mobileOtp.append('otp', $("#verification-code").val());
        mobileOtp.append('_csrf', $("meta[name=_csrf]").attr("content"));
        $.ajax({
          async: false,
          url: $('.otp').data('verify'),
          type: 'POST',
          data: mobileOtp,
          processData: false,
          contentType: false,
          success: function (success) {
            registrationPageFun.handleLoader(false);
            $("#register").trigger("submit");
          },
          error: function (error) {
            //$('#otp-error-code').removeClass('d-none').text('The SMS verification code is invalid');
            $errorMessage.removeClass('d-none').text('The SMS verification code is invalid');
            registrationPageFun.handleLoader(false);
          }
        });
      },

      trimmingUserName: function (name) {
        var trimmedText = name.val().replace(/\s+/g, ' ').trim();
        name.val(trimmedText);
      },

      pageOnloadEvents: function () {
        $('#second-mobile-number').val($('#input-mobile').val());
      }
    }
    registrationPageFun.pageOnloadEvents();

    $('[data-toggle="popover"]').popover();

    $(document).on('click', '.info-icon-toggle', function(){
      $('.top-info-text-desc').toggleClass('d-none');
      $('.info-icon').toggleClass('rotated');
    });

    $('#input-password').keydown(function () {
      commonFunctionality.passwordEyeKey($('#input-password'), $('#regi-eye'));
      commonFunctionality.passwordPopover($('#input-password').val());
    });

    $(document).on('click', '#regi-eye', function () {
      commonFunctionality.passwordShowHide($('#input-password'), $('#regi-eye'));
    });

    $(document).on('click', '#go-next', function () {
      var isValidNumber;
      if ($.trim($('#input-mobile').val())) {
        if ($('#input-mobile').intlTelInput("isValidNumber")) {
          var getCode = $('#input-mobile').intlTelInput('getSelectedCountryData').dialCode;
          $('#second-mobile-number').val(getCode + $('#input-mobile').val());
          isValidNumber = true;
        } else {
          isValidNumber = false;
        }
      }
      if (registrationPageFun.validation(isValidNumber)) {
        if (registrationPageFun.lookupMobile($('#second-mobile-number')) && registrationPageFun.lookupEmail($('#input-email'))) {
          registrationPageFun.sendOTPtoMobileNumber(false);
          registrationPageFun.handleLoader(true);
        }
      }
    });

    $(document).on('click', '#direct-signup', function () {
    	if (registrationPageFun.validation(true) == true && isResendRequestExpired == true) {
    		$("#register").trigger("submit");
    	}
    });
    
    $(document).on('click', '#go-back', function () {
      clearInterval(otptiming);
      $errorMessage.addClass('d-none');
      isResendRequested = false;
      isResendRequestExpired = false;
      $('.opt-section').removeClass('active');
      $('.form-section').addClass('active');
    });

    $(document).on('click', '#resend-otp', function () {
      if (registrationPageFun.validation(true)) {
        registrationPageFun.sendOTPtoMobileNumber(true);
        registrationPageFun.handleLoader(true);
        isResendRequested = true;
        isResendRequestExpired = false;
        $('#go-back').show();
      }
    });

    $('#verify-otp').click(function (e) {
      e.preventDefault();
      commonFunctionality.hideErrorMsg();
      if (registrationPageFun.validation(true) == true && isResendRequestExpired == true) {
    	  $("#register").trigger("submit");
    	  
      } else if ($('#verification-code').val().length == 0) {
        $('#verification-code').addClass('error-line');
        //$('#verification-code').siblings('.errorMsg').removeClass('d-none').text('Required Field');
        $errorMessage.removeClass('d-none').text('Required Field');
        
      } else if ($('#verification-code').val().length != 6) {
        $('#verification-code').addClass('error-line');
        //$('#verification-code').siblings('.errorMsg').removeClass('d-none').text('The SMS verification code is invalid');
        $errorMessage.removeClass('d-none').text('The SMS verification code is invalid');
        
      } else {
      	registrationPageFun.OTPVerifyFun();
        registrationPageFun.handleLoader(true);
      }
    });

    $('#submit-btn').click(function (e) {
      e.preventDefault();
      commonFunctionality.hideErrorMsg();
      registrationPageFun.trimmingUserName($('#input-first-name'));
      registrationPageFun.trimmingUserName($('#input-last-name'));
      if ($('#input-first-name').val() == "") {
        $('#input-first-name').addClass('error-line');
        $('#input-first-name').siblings('.errorMsg').removeClass('d-none').text('Required field');
        isValidated = false;
      } else if (!/^[a-zA-Z ]+$/.test($('#input-first-name').val())) {
        $('#input-first-name').addClass('error-line');
        $('#input-first-name').siblings('.errorMsg').removeClass('d-none').text('Special characters and number are not allowed');
        isValidated = false;
      } else if (!/^[a-zA-Z ]+$/.test($('#input-last-name').val())) {
        $('#input-last-name').addClass('error-line');
        $('#input-last-name').siblings('.errorMsg').removeClass('d-none').text('Special characters and number are not allowed');
        isValidated = false;
      } else if (!/^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9])[a-zA-Z0-9!@#$%^&*]{8,16}$/.test($('#input-password').val())) {
        commonFunctionality.passwordPopover($('#input-password').val());
        $('#input-password').addClass('error-line');
        $('#input-password').siblings('.errorMsg').removeClass('d-none').text("Password criteria mismatch");
        isValidated = false;
      } else if (registrationPageFun.validation()) {
        registrationPageFun.handleLoader(true);
        $("#register").trigger("submit");
      }
    });
    
    featuredVariables.flipDataPoints();
  }
  return {
    init: init
  };
})();


// $('#input-mobile').popover({
//   placement: 'top',
//   html: true,
//   title: '<p><a href="#" class="close" data-dismiss="alert">&times;</a></p>',
//   content: '<div> <p> If you are an NIR/OCI, please  ensure you transact through your NRO account></p> </div>'
// });

// $('#input-mobile').trigger('click');

// $('.popover').remove();
// $('#input-mobile').popover('hide');