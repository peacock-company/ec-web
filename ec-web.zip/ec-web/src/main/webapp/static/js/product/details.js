var borrowerDetails = (function () {
  function init(){
  var borrowerSlider = (function () {

    var video = $(".borrower-video video")[0];
    $('[data-toggle="tooltip"]').tooltip();
    // Chart.plugins.unregister(ChartRepaymentDataLabel);

    $("#borrower-slider").removeClass('d-none').slick({
      arrows: false,
      prevArrow: '<span><i class="fas fa-chevron-left"></i></span>',
      nextArrow: '<span><i class="fas fa-chevron-right"></i></span>',
      autoplay: false,
      infinite: false,
      dots: true,
      customPaging: function (slider, i) {
        var thumb = (($(slider.$slides[i]).find('img').attr('src') == undefined) ?
          $(slider.$slides[i]).find('video').data('poster') :
          $(slider.$slides[i]).find('img').attr('src'));
        return '<a><img src="' + thumb + '"></a>';
      }
    });
    $(document).on("click", ".borrower-video .fa-pause", function () {
      video.pause();
      $(this).toggleClass("fa-pause fa-play");
    });
    $(document).on("click", ".borrower-video .fa-play", function () {
      video.play();
      $(this).toggleClass("fa-pause fa-play");
    });
    $(document).on("click", ".borrower-video .fa-volume-up", function () {
      video.muted = false;
      $(this).toggleClass("fa-volume-up fa-volume-mute");
    });
    $(document).on("click", ".borrower-video .fa-volume-mute", function () {
      video.muted = true;
      $(this).toggleClass("fa-volume-up fa-volume-mute");
    });
  })();

  var invest = (function () {
    var $investInput = $("input[name=txnAmount]");
    var $investBtn = $(".invest-now-btn");
    var $defaultContrib = $(".default-contrib");
    var $stickySections = $(".fixed-invest-progress, .fixed-invest-contrib");
    var $investorCount = ((window.innerWidth < 768) ? 4 : 6);

    if ($(window).width() < 500)
      $(".invest-container .btn-primary").html("Invest");

    //$(document).on("click", ".invest-now-btn", showPredefinedAmounts);
    $(document).on("click", ".borrower-loan-fulfil", function (ev) {
      var remainingAmount = $(this).data('remaining');
      $(this).closest('form').find('input[name=txnAmount]').val(remainingAmount);
      $(this).closest('form').find('input[name=txnAmount]').attr("value", remainingAmount);
      //$("input[name='txnAmount']").trigger('keyup');
    });

    $(document).on("submit", ".add-to-cart", function (ev) {
      ev.preventDefault();
      var $addToCart = $("#invest-btn-top");
      $addToCart.attr("disabled", true);
      var $txnAmountInput = $(this).find("input[name='txnAmount']");
      var txnAmount = $txnAmountInput.val().replace(/^0+/, '');
      $.ajax({
        url: $(this).attr("action"),
        method: "POST",
        data: $(this).serialize()
      }).done(function (response) {
        $addToCart.removeAttr("disabled");
        $(".cart-count").html(response.items.length).removeClass("d-none");
        $(".form-wrap, .form-success").toggleClass("d-none");
        $txnAmountInput.val(txnAmount);
        $txnAmountInput.attr('value', txnAmount);
        $('.cart-added-msg span').text($("input[name=txnAmount]").val());
        $('.fixed-invest-grid').addClass('d-none');
      }).fail(function (error) {
        $addToCart.removeAttr("disabled");
        if (error.status == 403) {
          window.location.href = error.getResponseHeader("login");
        } else {
          response = JSON.parse(error.responseText);
          $(".form-error").html(response.messages[0].message);
        }
      });
    });
    window.addEventListener("scroll", toggleFixedFooter);

    $(document).on('click', '.edit-feature', function () {
      $(".form-success").addClass("d-none");
      $(".form-wrap").removeClass("d-none");
      $(".fixed-invest-grid").removeClass("d-none");
    });

    function showPredefinedAmounts(ev) {
      ev.preventDefault();
      $defaultContrib.removeClass("l-hide");
      $stickySections.toggleClass("l-hide ");
      $investInput.removeClass("d-none");
      $(".invest-container").css("display", "grid");
      $(".invest-now-btn").removeClass("invest-now-btn");
    }

    function toggleFixedFooter() {
        if ($("#invest-btn-top")[0])
        	if (commonFunctionality.isInViewport($(".bottom-fixed")[0])) {
    		  $(".fixed-invest").addClass("l-hide");
    		  $('#chatra').removeClass('shift');
    		} else {
    		  $(".fixed-invest").removeClass("l-hide");
    		  $('#chatra').addClass('shift');
    		}
      }

    function validateAmount(amount, pendingAmount) {
      var $formError = $(".form-error");
      var $formWarn = $(".form-warn");
      var loanKey = $("input[name='loanKey']").val();
      var txnAmount = $("input[name=txnAmount]").val();

      $formError.html("");
      $formWarn.html("");

      var error = commonFunctionality.validateAmount(amount, pendingAmount);
      $formError.html(error.amount);
      error.amount ? $investBtn.attr("disabled", true) : $investBtn.removeAttr("disabled");

      if (!error.amount) {
        var validate = commonFunctionality.validateAgainstCart(loanKey, txnAmount);
        $formError.html(validate.error);
        $formWarn.html(validate.warning);
        validate.error ? $investBtn.attr("disabled", true) : $investBtn.removeAttr("disabled");
      }
    }

    $(document).on("keyup", "input[name='txnAmount']", function () {
      var $input = $("input[name=txnAmount]");
      var amount = $(this).val();
      var $form = $(this).closest('form');

      var $activeSuggestedAmountButton = $form.find('.suggested-amounts button.active');
      var $activeSuggestedAmount = $activeSuggestedAmountButton.data("amount");
      if (!($activeSuggestedAmountButton.length && ($activeSuggestedAmount == amount) && (amount == 500 || amount == 1000 || amount == 2000))) {
        $('.suggested-amounts').removeClass('active');
      }

      $input.val(amount);
      validateAmount(amount, remainingAmount);
    });

    $(document).on("click", ".btn-invest-amount", function (ev) {
      ev.preventDefault();
      $('.suggested-amounts').find('button').removeClass('active');
      $(this).addClass('active');
      var $input = $("input[name=txnAmount]");
      var amount = $(this).data("amount");
      $input.val(amount);
      validateAmount(amount, remainingAmount);
    });

    $('.social-investor').each(function (i) {
      // var bacgColor = '#' + Math.floor(Math.random()*16777215).toString(16);
      // $(this).children('.placeholder').css('background-color', bacgColor);
      if (i > $investorCount - 1) {
        $(this).addClass('d-none');
        $('.show-more-wrapper').removeClass('d-none');
      }
    });

    $(document).on('click', '#show-more', function () {
      var showMoreSet = $('.social-investor.d-none').slice(0, $investorCount);
      showMoreSet.removeClass('d-none');
      if ($('.social-investor.d-none').length === 0) {
        $('.show-more-wrapper').addClass('d-none');
      }
    });

    $(document).on('mouseenter', '.borrower-rating-info', function (event) {
      $('.borrower-rating-table').show();
      event.stopPropagation();
    });

    $(document).on('mouseleave', '.borrower-rating-info', function (event) {
      $('.borrower-rating-table').hide();
      event.stopPropagation();
    });

    $(document).on('click', '.borrower-rating-info', function (event) {
      $('.borrower-rating-table').toggle();
      event.stopPropagation();
    });

    $(document).on("click", ".infotip", function (event) {
      event.stopPropagation();
    });

    $(document).on('click', '.days-of-livelihood-info', function (event) {
      $('.days-of-livelihood').toggle();
      event.stopPropagation();
    });

    $(document).on("click", ".days-of-livelihood", function (event) {
      event.stopPropagation();
    });

    $(window).on("click", "body", function (event) {
      if ($('.borrower-rating-table').is(":visible")) {
        $('.borrower-rating-table').hide();
      }
      if ($('.days-of-livelihood').is(":visible")) {
        $('.days-of-livelihood').hide();
      }
      event.stopPropagation();
    });

    $(document).on('click', '.slick-dots', function () {
      $('.slick-slide').each(function () {
        if (!$(this).hasClass('slick-active')) {
          $(this).find('video').trigger('pause');
        }
      });
    });

    $(document).on('click', '.interest-rate-type-btn', function (){
        $('.interest-rate-type-btn').removeClass('green-active');
        $(this).addClass('green-active');
        if($(this).text() == 'Believer'){
          $('.believers-display').removeClass('d-none');
          $('.seekers-display').addClass('d-none');
        } else {
          $('.believers-display').addClass('d-none');
          $('.seekers-display').removeClass('d-none');
        }
      });
    
    function repaymentStatus() {
      var repaymentRate = Number($('.repaymentRate').text()), 
      defaultRepaymentRate = Number($('.defaultRepaymentRate').text()),
      delayedRepaymentRate = Number($('.delayedRepaymentRate').text()),
      repaidAmount =  Number($('.repaidAmount').text()),
      delayedAmount = Number($('.delayedAmount').text()),
      defaultAmount = Number($('.defaultAmount').text());
      console.log(Number(defaultAmount));
      
      var ctx = $("#repayment-status").get(0).getContext("2d");
      ctx.canvas.height = (window.innerWidth < 768) ? 160 : 120;
      var chart = new Chart(ctx, {
        plugins: [],
        type: 'horizontalBar',
        data: {
          labels: [
            "On Time",
            "Delayed",
            "Default"
          ],
          amountLabels: [repaidAmount, delayedAmount, defaultAmount],
          datasets: [{
            label: "reapyment",
            backgroundColor: ["#5dc0a3", "#6ba2f1", "#e3735d"],
            data: [repaymentRate, delayedRepaymentRate, defaultRepaymentRate]
          }, {
            label: "reapyment-empty",
            backgroundColor: "#cbd1db",
            data: [100 - repaymentRate, 100 - delayedRepaymentRate, 100 - defaultRepaymentRate]
          }]
        },
        options: {
          barRoundness: 4.9,
          tooltips: {
            enabled: false
          },
          scales: {
            yAxes: [{
              stacked: true,
              barThickness : 32,
              barPercentage: 0.1,
              categoryPercentage: 0.1,
              ticks: {
                beginAtZero: true,
                fontSize: 13,
                fontStyle: 'bold'
              },
              gridLines: {
                display: false,
                drawBorder: false
              }
            }],
            xAxes: [{
              stacked: true,
              display: false,
              ticks: {
                beginAtZero: true,
                fontSize: 13,
                fontStyle: 'bold'
              },
            }]
          },
          legend: {
            display: false,
          },
          plugins: {
            datalabels: {
              align: 'right',
              anchor: 'start',
              offset: '10',
              color: '#000000',
              font: {
                weight: 'bold'
              }, 
                formatter: function (value, context) {
                  var labelValue = context.chart.data.amountLabels[context.dataIndex];
                  return labelValue > 0 && context.datasetIndex === 0 ? '₹ ' + labelValue : '';
                }
            }
          }
        }
      });
    }
    repaymentStatus();
  })();
  } return {
    init: init
  };
})();

// var xhr = $.get(context + "dashboard/repayments-tab-3");
// xhr.done(function (response) {
//   $('#on-time-repayment').text(Number(response.repaymentStatusTab.repaymentRate) + '%');
//   $('#delayed-time-repayment').text(Number(response.repaymentStatusTab.delayedRepaymentRate) + '%');
//   $('#default-time-repayment').text(Number(response.repaymentStatusTab.defaultRepaymentRate) + '%');
//   $('#total-repayment, .total-repayment-rate').text(Math.ceil((Number(response.repaymentStatusTab.delayedRepaymentRate) + Number(response.repaymentStatusTab.repaymentRate))) + '%');
//   $('.total-repayment-rate').text(Math.ceil(Number(response.repaymentStatusTab.overallRangDeRepaymentRate)) + '%');