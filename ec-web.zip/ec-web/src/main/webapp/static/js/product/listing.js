// our progress data start 
$( document ).ready(function() {
  if ($('.recent-commits-ticker-slider').length == 1 && $('.recent-commits-ticker-slider > div').length > 1) {
    $('.recent-commits-ticker-slider').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 3000,
        cssEase: 'ease-in-out',
        adaptiveHeight: true,
        vertical: true,
        arrows: false,
        dots: false,
      });
    }

  // var todayDate = new Date();
  // var EndDate = new Date(2020, 10, 13);

  // if(todayDate >= EndDate){
  //   $(".diwali-img-lg").addClass("d-none"); 
  //   $(".our-progress-main").removeClass("d-none");
  //   if (window.innerWidth < 768){
  //     $(".diwali-img-sm").addClass("d-none");  
  //   } 
  // }else{
  //   $(".diwali-img-lg").removeClass("d-none"); 
  //   $(".our-progress-main").addClass("d-none"); 
  //   if (window.innerWidth < 768){
  //     $(".diwali-img-sm").removeClass("d-none");  
  //   } 
  // }

  if (window.innerWidth < 768){
  $(".slider").slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    infinite: true,
    autoplay: true,
    autoplaySpeed: 2000,
    centerMode: true,
    centerPadding: '2%',
    arrows: false,
    dots: false,
  });
 
  window.addEventListener("scroll", StickyBar);  
  function StickyBar() {
      if (commonFunctionality.isInViewport($("#sticky-show")[0])) {
      $(".fixed-commit-funds").addClass("l-hide");
      $('#chatra').removeClass('shift');
    } else {
      $(".fixed-commit-funds").removeClass("l-hide");
      $('#chatra').addClass('shift');
    }
  }
 }
 });
  // our progress data end
  
var filters = (function () {
  var $clearButton = $(".clear-all");
  var $filterButton = $(".filter-action-icon");
  var $filterForm = $(".filter-form");
  var $filterSections = $(".filter-sections");
  var $filterCategory = $(".filter-buttons div");
  var $filterSectionsModal = $(".filter-section-sm");
  var $sortBy = $(".filter-sections .sortby");
  var $loandStatusFilter = $(".filter-sections .loan-status-filter");
  var $editCart = $('.investment-success .edit-cart');
  var $suggestedAmounts = $('.invest-form .default-contrib button');
  var params = commonFunctionality.urlParamsObj();

  var $whatsappLink = $('#whatsapp-link');
  var $facebookLink = $('#facebook-link');
  var $linkedinLink = $('#linkedin-link');
  var $twitterLink = $('#twitter-link');
  var $mailLink = $('#mail-link');
  var $copyLink = $('.copy-link-input');
  var $loanBorrowerName = $('.share-loan-borrower-name');
  
  //$filterButton.on("click", showFilter);
  $clearButton.on("click", clearFilters);
  $filterForm.on("submit", filterBorrowers);
  $filterCategory.on("click", showFilterCategory);
  $editCart.on("click", showEdit);
  $suggestedAmounts.on('click', setSuggestedAmount);
  $sortBy.on('click', showSortBy);
  $loandStatusFilter.on('click', showLoanStatus);
  render();

  $(document).on("click", "body", function (event) {
    if (!$(event.target).closest('.filter-form').length && ($('.filter-form').is(":visible"))) {
      $('.filter-form').hide();
      $filterCategory.removeClass('active');
    }
    if ($('.sortby-cases, .loan-status-case').is(":visible")) {
      $('.sortby-cases, .loan-status-case').hide();
      $('.sortby, .loan-status').removeClass('active');
    }
    event.stopPropagation();
  });

  function showFilter(event) {
    $filterSections.toggle();
    event.stopPropagation();
  }

  function showFilterCategory(event) {
    $('.sortby-cases').hide();
    $('.sortby').removeClass('active');
    var filter = $(this).data("filter");
    if (filter === "state" || filter === "sector") {
      $filterCategory.removeClass('active');
      $(".filter-form").show();
      $('.filter-background').removeClass('d-none');
      $(".filter-form > section").hide();
      $(this).addClass('active')
      $(".filter-form ." + filter).css('display', 'flex');
    }
    event.preventDefault();
    event.stopPropagation();
  }

  function clearFilters(event) {
    //$(this).parent().find("input[type=checkbox]").prop("checked", false);
    $filterForm = $(this).closest('.filter-form');
    if ($filterForm.find('.state').is(":visible")) {
      $filterForm.find('.state input[type=checkbox]').prop("checked", false);
    } else if ($filterForm.find('.sector').is(":visible")) {
      $filterForm.find('.sector input[type=checkbox]').prop("checked", false);
    }
    $('.sort-section input[type=checkbox]').prop("checked", false);
    //event.preventDefault();
    //event.stopPropagation();
  }

  function showSortBy() {
    $('.filter-form, .extra-filters').hide();
    $filterCategory.removeClass('active');
    $('.sortby').addClass('active');
    $('.sortby-cases').toggle();
  }

  function showLoanStatus() {
    $('.filter-form, .extra-filters').hide();
    $filterCategory.removeClass('active');
    $('.loan-status-case').addClass('active');
    $('.loan-status-case').toggle();
  }

  $('.sortby-cases div').on('click', function () {
    var sorts = $(this).data('case').split(",");
    $('.sort-section input').prop('checked', false);
    sorts.forEach(function (el) {
      $("#" + el).prop("checked", true);
    });
    $('.filter-form .apply').trigger('click');
  });

  $('.loan-status-case div').on('click', function () {
    var status = $(this).data('case').split(",");
    $('.loan-status-section input').prop('checked', false);
    status.forEach(function (el) {
      $("#" + el).prop("checked", true);
    });
    $('.filter-form .apply').trigger('click');
  });

  $('.filter-section-title .icon-close').on('click', function () {
    $('.filter-form').hide();
    $filterCategory.removeClass('active');
    $('.filter-background').addClass('d-none');
  });

  var paramValue  = window.location.search.includes('REPAYMENT_IN_PROGRESS') || window.location.search.includes('READY_FOR_DISBURSAL');
  if(paramValue){
    $('.count-amount').addClass('d-none');
    $('.addingClick').removeClass('d-none')
  } else {
    $('.count-amount').removeClass('d-none');
    $('.addingClick').addClass('d-none')
  }

  var loanType  = window.location.search.includes('SSI');
  if(loanType){
    $('.needing-lona-note').addClass('d-none');
  }
  

  $(document).on('click', '.click-to-in-need', function(){
    $('.in-need-case-handle').trigger('click');
  })

  function filterBorrowers(ev) {
    ev.preventDefault();
    // console.log(location.href.split("?")[0], $(this).serialize());
    // location.href = $(this).serialize() ? location.href.split("?")[0] + '?' + $(this).serialize() : location.href.split("?")[0];
    if($('.param-value-for-tabs').text() == 'snehalaya'){
      location.href = $(this).serialize() ? location.href.split("?")[0] + '?partners=snehalaya&' + $(this).serialize() : location.href.split("?")[0];
    } else {
       location.href = $(this).serialize() ? location.href.split("?")[0] + '?' + $(this).serialize() : location.href.split("?")[0];
    }
  }

  function setFilterValues() {
    $('.filter-buttons .btn-transparent').removeClass('active-highlight');
    Object.keys(params).map(function (key) {
      if (key == 'region' || key == 'sector' || key == 'sort' || key == 'status') {
        $('#' + key).addClass('active-highlight');
      }

      var values = params[key].split(",");
      values.forEach(function (el) {
        el = decodeURIComponent(el).replace(/[^a-zA-Z ]/g, "-");
        $("#" + el).prop("checked", true);
        $("#" + el + "-sm").prop("checked", true);
      });

      if (key == 'sort') {
        $('.sortby-cases div').each(function (el) {
          if ($(this).data('case') == values.join(',').replace(/[^a-zA-Z, ]/g))
            $(this).addClass('font-weight-bold');
        });
      }

      if (key == 'status') {
        $('.loan-status-case div').each(function (el) {
          var status = values[0];
          if ($(this).data('case') == status) {
        	$('.loan-status-section #' + status).prop("checked", true);
            $(this).addClass('font-weight-bold');
          }
        });
      }
    });
  }

  function render() {
    Object.keys(params).length ? setFilterValues() : '';
  }

  function showEdit() {
    $borrowerInvestCard = $(this).closest('.borrower-data-invest');
    $borrowerInvestCard.find('.investment-success').hide();
    $borrowerInvestCard.find('.invest-form').show();
  }

  function setSuggestedAmount() {
    $(this).closest('.default-contrib').find('button').removeClass('active');
    $(this).addClass('active');
    var $investForm = $(this).closest('.invest-form');
    var $txnAmountInput = $investForm.find('input[name="txnAmount"]')
    $txnAmountInput.attr('value', $(this).data('amount'));
    $txnAmountInput.val($(this).data('amount'));
    $txnAmountInput.trigger('keyup');
  }

  $(document).on("click", '.share-btn', function(ev) {
	 var whatsappLinkData = $(this).data("whatsapp");
	 var facebookLinkData = $(this).data("facebook");
	 var linkedinLinkData = $(this).data("linkedin");
	 var twitterLinkData = $(this).data("twitter");
	 var mailLinkData = $(this).data("mail");
	 var copyLinkData = $(this).data("link");
	 var borrowerName = $(this).data("name");
	 
	 $whatsappLink.attr("href", whatsappLinkData);
	 $facebookLink.attr("href", facebookLinkData);
	 $linkedinLink.attr("href", linkedinLinkData);
	 $twitterLink.attr("href", twitterLinkData);
	 $mailLink.attr("href", mailLinkData);
	 $copyLink.val(copyLinkData);
	 $loanBorrowerName.text(borrowerName);
	 
  });
})();

var genericBorrowersFeed = (function () {
  var $step1 = $(".invest, .borrower-card-fulfill");
  var $borrowers = $(".borrower-card-container");
  var $amountInput = $(".input-container");

  function showCartAmountInput($cartForm, lendingAmount) {
    var $addToCart = $(".btn-add-cart");
    $(".form-error").html("");
    $cartForm.find("input.amount").val(lendingAmount);
  }

  /*$(document).on("mouseover", ".borrower-card-container", function () {
    $borrowers.removeClass("active");
    $(this).addClass("active");
  });*/

  $(document).on("click", ".borrower-card-fulfill", function (ev) {
    ev.preventDefault();
    var remainingAmount = $(this).data("pending");
    var $cartForm = $(this).prev();
    showCartAmountInput($cartForm, remainingAmount);
    $cartForm.find(".btn-add-cart").removeAttr("disabled");
    $(this).closest(".invest-form").find(".amount").trigger("keyup");
  });

  /*$(document).on("click", ".btn-invest", function (ev) {
    ev.preventDefault();
    var $cartForm = $(this).parent();
    showCartAmountInput($cartForm, "");
  });*/

  $(document).on("click", ".btn-add-cart", function (ev) {
    ev.preventDefault();
    var $this = $(this);
    $this.attr("disabled", true);
    var $cartForm = $this.closest("form");
    var $addedCartLable = $(this).parents(".borrower-card").find('.invest-cart-label');
    var $cartFormContainer = $this.closest(".invest");
    var $txnAmountInput = $cartForm.find('input[name="txnAmount"]');
    var txnAmount = $txnAmountInput.val().replace(/^0+/, '');
    $.ajax({
        url: $cartForm.attr("action"),
        method: "POST",
        data: $cartForm.serialize()
      })
      .done(function (response) {
        $(".cart-count").html(response.items.length).removeClass("d-none");
        $cartFormContainer.find(".invest-form").hide();
        $investmentSuccess = $cartFormContainer.find(".investment-success");
        $investmentSuccess.show();
        $txnAmountInput.val(txnAmount);
        $txnAmountInput.attr('value', txnAmount);
        $investmentSuccess.find('.investment-amount').html($txnAmountInput.val());
        $addedCartLable.removeClass('d-none');
        updateCartLocalStorage(response);
        $txnAmountInput.trigger('keyup');
        $this.removeAttr("disabled");
      })
      .fail(function (error) {
        if (error.status == 403) {
          window.location.href = error.getResponseHeader("login");
        } else {
          response = JSON.parse(error.responseText);
          $cartForm.find(".form-error").html(response.messages[0].message);
          $cartForm.find(".form-warn").hide();
        }
        $this.removeAttr("disabled");
      });
  });

  $(document).on("keyup", ".amount", function () {
    var $investSection = $(this).closest('.invest-form');
    var $cartForm = $(this).closest("form");
    var $addToCart = $cartForm.find("button");

    var $formError = $cartForm.find(".form-error");
    var $formWarn = $cartForm.find(".form-warn");

    var loanKey = $cartForm.find("input[name='loanKey']").val();
    var txnAmount = $(this).val();
    var pendingAmount = $(this).data("pending");

    $formError.html("");
    $formWarn.html("");

    var $activeSuggestedAmountButton = $investSection.find('.default-contrib button.active');
    var $activeSuggestedAmount = $activeSuggestedAmountButton.data("amount");
    if (!($activeSuggestedAmountButton.length && ($activeSuggestedAmount == txnAmount) && (txnAmount == 500 || txnAmount == 1000 || txnAmount == 2000))) {
      $investSection.find('.default-contrib button').removeClass('active');
    }

    var error = commonFunctionality.validateAmount(txnAmount, pendingAmount);
    $formError.html(error.amount);
    error.amount ? $addToCart.attr("disabled", true) : $addToCart.removeAttr("disabled");
    if (error.amount === "") {
      var validate = commonFunctionality.validateAgainstCart(loanKey, txnAmount);
      $formError.html(validate.error);
      $formWarn.html(validate.warning);
      validate.error ? $addToCart.attr("disabled", true) : $addToCart.removeAttr("disabled");
    }

  });

  $(document).on("click", ".borrower-data-invest .chevron-up", function (ev) {
    var $cartForm = $(this).closest("form");
    var $inputContainer = $cartForm.find(".input-container");
    var $txnAmountInput = $inputContainer.find('input[type="number"]');
    $txnAmountInput[0].stepUp();
    $txnAmountInput.trigger("keyup");
  });

  $(document).on("click", ".borrower-data-invest .chevron-down", function (ev) {
    var $cartForm = $(this).closest("form");
    var $inputContainer = $cartForm.find(".input-container");
    var $txnAmountInput = $inputContainer.find('input[type="number"]');
    $txnAmountInput[0].stepDown();
    $txnAmountInput.trigger("keyup");
  });
  
  function updateCartLocalStorage(response) {
    if (response.items && response.items.length <= 0 && !cartItemsCount.hasClass("d-none"))
      cartItemsCount.html("").addClass("d-none");

    else if (response.items && response.items.length > 0) {
      localStorage.setItem("cartItems", JSON.stringify(response.items));
      cartItemsCount.html(response.items.length).removeClass("d-none");
    }
  }
  $(document).on("click", ".commit-btn", function () {
    investPage = window.location.href.split('/')[3];
    sessionStorage.setItem("investPage",investPage);
  });
  window.addEventListener("scroll", toggleFixedFooter);  
  function toggleFixedFooter() {
      if (commonFunctionality.isInViewport($("#invest-in-farmers")[0])) {
      $(".fixed-commit-funds").addClass("l-hide");
      $('#chatra').removeClass('shift');
    } else {
      $(".fixed-commit-funds").removeClass("l-hide");
      $('#chatra').addClass('shift');
    }
  }
})();

var pagination = (function () {
  var isPinkCapital = $('.isPinkCapital').text();
  var $paginationContainer = $(".pagination");
  var totalBorrowers = $("#pagination").data("totalborrowers");
  var uriObject = commonFunctionality.urlParamsObj();
  var currentPage = uriObject.page ? Number(uriObject.page) : 0;

  delete uriObject.page;
  delete uriObject.size;
  uriObject = commonFunctionality.createSearchUri(uriObject);
  var pager = commonFunctionality.pagination(totalBorrowers, currentPage, 9, 3);

  var href= "invest?" + uriObject;
  if(isPinkCapital == 'true'){
	  href= "pinkcapital?" + uriObject;
  }
  var paginateTemplate = '';
  if (currentPage != 0 || currentPage < 0) {
    paginateTemplate += '<li class="page-item">' +
      '<a id="prev-page" class="page-link" href="/' + href + 'page=' + (currentPage - 1) + '">Prev</a>' +
      '</li>';
  }
  pager.pages.forEach(function (page) {
    paginateTemplate += '<li class="page-item ' + ((currentPage == page - 1) ? "active" : "") + '">' +
      '<a class="page-link" href="/' + href + 'page=' + (page - 1) + '">' + page + '</a>' +
      '</li>';
  });
  if (currentPage != pager.totalPages - 1) {
    paginateTemplate += '<li class="page-item">' +
      '<a id="next-page" class="page-link" href="/' + href + 'page=' + (currentPage + 1) + '">Next</a>' +
      '</li>';
  }
  $paginationContainer.html(paginateTemplate);
  if($('.param-value-for-tabs').text()){
    $('#' + $('.param-value-for-tabs').text()).addClass('active');
  } else {
    $('#ORGANIC').addClass('active');
  }

  if($('.param-value-for-tabs').text() == 'snehalaya'){
    $('#region, #sector, #status').remove();
    // $('.loan-status-case').css('right', '-115px');
    $('.borrower-card-container').removeClass('delay-view');
    $('.sortby-cases').css('right', '-131px');
  }
 
})();
