var loginPage = (function () {
  function init() {
    var isResendRequested = false;
    var isResendRequestExpired = false;
    var isViaEmail = true;
    var isViaMobileNumber = false;
    var isViaLogin = false;
    var isViaSignup = false;
    var isOrgNotRegUser = false;
    
    var mobileNumberWithCode;
    
    //relative path
    var context = $('.relative-path').attr('href');
    var signupRelativePath = $('#signup-url').attr('href');
    var setPasswordRelativePath = $('#set-password-url').attr('href');
    var lookupPath = $('.lookup-path').attr('href');
    
    //login
    var $emailId = $('#email-id');
    var $emailPassword = $('#email-password');
    
    var $mobileNumber = $('#mobile-number');
    var $verificationCode = $('#verification-code');
    
    var $username = $('#username');
    var $password = $('#password');
    var $rememberMe = $('.remember-me');
    
    var $maskedUsername = $('.masked-email');
    var $maskedMobilenumber = $('.masked-mobile-number');
    //signup
    var $regEmail = $('#email');
    var $regMobileNumber = $('#mobileNumber');
    
    $errorMessage = $('.errorMsg');
    
    //start: country code drop-down
    $('#mobile-number').intlTelInput({
      utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/16.0.3/js/utils.js",
      initialCountry: "auto",
      separateDialCode: true,
      geoIpLookup: function (success, failure) {
        $.get("https://ipinfo.io", function () { }, "jsonp").always(function (resp) {
          var countryCode = (resp && resp.country) ? resp.country : "";
          success(countryCode);
        });
      },
    });
    //end: country code drop-down
    
    //start: validate actions
    var validate = {
    	email: function(isViaLogin) {
    		commonFunctionality.hideError();
    		$emailId.val($.trim($emailId.val()));
            
    		var isValidated = false;
            if ($emailId.val() == '') {
              $emailId.addClass('error-line');
              $errorMessage.show().text('Please enter your email address to continue investing');
              isValidated = false;
              
            } else if (!/^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]{2,})+$/.test($emailId.val())) {
              $emailId.addClass('error-line');
              $errorMessage.show().text('Please enter a valid email address');
              isValidated = false;
              
            } else if (isViaLogin && $emailPassword.val() == '') {
              $emailPassword.addClass('error-line');
          	  $errorMessage.show().text('Please enter your password to continue investing');
              isValidated = false;
                
            } else {
              $username.val($emailId.val());
              $password.val($('#email-password').val());
              isValidated = true;
            }
            return isValidated;
    	},
    	mobile: function(isViaLogin) {
    		commonFunctionality.hideError();
    		$mobileNumber.val($mobileNumber.val().replace(/\s/g, ""));
    		var isValidated = false;
            if ($mobileNumber.val() == '') {
          	  $mobileNumber.addClass('error-line');
              $errorMessage.show().text('Please enter your mobile number to continue investing');
              isValidated = false;
              
            } else if ($mobileNumber.val()[0] == 0) {
          	  $mobileNumber.addClass('error-line');
              $errorMessage.show().text('Please enter a valid mobile number');
              isValidated = false;
              
            } else if (isViaLogin && $verificationCode.val() == '') {
              $verificationCode.addClass('error-line');
              $errorMessage.show().text('Please enter OTP');
              isValidated = false;
              
            } else if (isViaLogin && $verificationCode.val().length != 6) {
              $verificationCode.addClass('error-line');
              $errorMessage.show().text('Please enter a valid OTP');
              isValidated = false;
              
            } else if ($.trim($mobileNumber.val())) {
              if ($mobileNumber.intlTelInput("isValidNumber")) {
                var getCode = $mobileNumber.intlTelInput('getSelectedCountryData').dialCode;
                mobileNumberWithCode = getCode + $mobileNumber.val();
                $('#otpForm input[name=mobileNumber]').val(mobileNumberWithCode);
                if (isViaLogin) {
                	$username.val(mobileNumberWithCode);
                    $password.val($('#verification-code').val());
                } else if (isViaSignup){
                	$regEmail.val($emailId.val());
                	$regMobileNumber.val(mobileNumberWithCode);
                }
                isValidated = true;
              }
              else {
            	$mobileNumber.addClass('error-line');
                $errorMessage.show().text('Please enter a valid mobile number');
                isValidated = false;
              }
            }
            return isValidated;
    	}
    };
    //end: validate actions 
    //start: otp actions
    var otp = {
      send: function () {
        $('#loader-overlay').removeClass('d-none');
        var $otpForm = $('#otpForm');
        //var form = $('#otpForm');
        var otpData = new FormData($otpForm[0]);
        $.post({
          url: $otpForm.attr('action'),
          data: otpData,
          processData: false,
          contentType: false,
          success: function (response) {
            $('#loader-overlay').addClass('d-none');
            $('.otp-message').show();
            otp.timer();
          },
          error: function (error) {
            $('#loader-overlay').addClass('d-none');
          }
        });
      },

      timer: function () {
        var timer = 60;
        var otptiming = setInterval(function () {
          countingTime();
        }, 1000);

        function countingTime() {
          $('#resend-otp').hide();
          timer = timer - 1
          if (timer != -1) {
            $('.timer-clock span').text(timer);
          } else {
            clearInterval(otptiming);
            $('#resend-otp').show();
            $('#verification-code').val('');
            if (isResendRequested) {
            	isResendRequestExpired = true;
            	lookup.passwordCheck();
            }
          }
        }
      },

    };
    //end: otp actions
    
    //start: lookup actions
    var lookup = {
      orgEmail: function (email) {
    	commonFunctionality.hideError();
        var isLookup;

        $.ajax({
          async: false,
          url: lookupPath + "/org-not-reg?email=" + encodeURIComponent(email.val()),
          method: "GET",
          contentType: "application/json",
          dataType: "json",
          success: function (successMsg) {
            isLookup = true;
            isOrgNotRegUser = false;
          },
          statusCode: {
          	400: function(response) {
          		isLookup = false;
          		$emailId.addClass('error-line');
          		$errorMessage.show().html("Please enter a valid email address");
          	},
          	409: function(response) {
          		isLookup = false;
          		isViaEmail = false;
          		isViaSignup = true;
            	isOrgNotRegUser = true;
          		reset.signup();
            }
          }
        });
        return isLookup;
      },
      
      email: function (email) {
          commonFunctionality.hideError();
          var isLookup;
          $.ajax({
            async: false,
            url: lookupPath + "?email=" + encodeURIComponent(email.val()),
            method: "GET",
            contentType: "application/json",
            dataType: "json",
            success: function (successMsg) {
              isLookup = false;
              if (isViaSignup) {
            	$mobileNumber.addClass('error-line');  
            	$errorMessage.show().html("Email is already being used");
          	  } else {
          		$errorMessage.show().html("Please  <a class='link-primary' href='" + signupRelativePath + "'>sign up</a> before you could start to invest");
          	  }
            },
            error: function (errorResponse) {
            	isLookup = true;
            }
          });
          return isLookup;
        },
        
      mobile: function () {
          commonFunctionality.hideError();
          var isLookup;
          $.ajax({
            async: false,
            url: lookupPath + "?mobileNumber=" + mobileNumberWithCode,
            method: "GET",
            contentType: "application/json",
            dataType: "json",
            success: function (successMsg) {
              isLookup = false;
              if (isViaSignup) {
            	isLookup = true;
          	  } else {
          		$errorMessage.show().html("Please  <a class='link-primary' href='" + signupRelativePath + "'>sign up</a> before you could start to invest");
          	  }
            },
            error: function (errorResponse) {
            	isLookup = true;
            	if (isViaSignup) {
            		isLookup = false;
            		$mobileNumber.addClass('error-line');  
                	$errorMessage.show().html("Mobile number is already being used");
            	}
            }
          });
          return isLookup;
      },
	  maskedEmail: function() {
		  commonFunctionality.hideError();
          var isMasked;
          var relativePath = $('.lookup-path').attr('href');

          $.ajax({
            async: false,
            url: relativePath + "/masked?mobileNumber=" + mobileNumberWithCode,
            method: "GET",
            contentType: "application/json",
            dataType: "json",
            statusCode: {
            	404: function(response) {
            		isMasked = false;
            		$errorMessage.show().html("Please  <a class='link-primary' href='" + signupRelativePath + "'>sign up</a> before you could start to invest");
            	},
            	400: function(response) {
            		isMasked = false;
            		$errorMessage.show().html("Please enter a valid mobile number");
            	},
            	200: function(response) {
            		isMasked = true;
        	        $maskedUsername.text(response.responseText);
            	}
            }
          });
          return isMasked;
	  },
      passwordCheck: function () {
          commonFunctionality.hideError();
          var isPasswordSet;
          var relativePath = $('.lookup-path').attr('href');

          $.ajax({
            async: false,
            url: relativePath + "/password-check?mobileNumber=" + mobileNumberWithCode,
            method: "GET",
            contentType: "application/json",
            dataType: "json",
            success: function (successMsg) {
              isPasswordSet = true;
              reset.loginActions('hide', '');
              reset.passwordActions('show', 'login-with-password');
              $errorMessage.show().html("Oops, looks like the network is bad. Could you try logging in with your <a class='link-primary login-with-password' href='#'>password</a>?");
            },
            statusCode: {
            	404: function(response) {
            		isPasswordSet = false;
            		$errorMessage.show().html("Please  <a class='link-primary' href='" + signupRelativePath + "'>sign up</a> before you could start to invest");
            	},
            	400: function(response) {
            		isPasswordSet = false;
            		$mobileNumber.addClass('error-line');
            		$errorMessage.show().html("Please enter a valid mobile number");
            	},
            	204: function(response) {
            		isPasswordSet = false;
            		reset.loginActions('hide', '');
            		reset.passwordActions('show', 'set-password');
            		$errorMessage.show().html("Oops, looks like the network is bad. Could you try logging in by creating a <a class='link-primary' href=' " + setPasswordRelativePath + " '>password?</a>");
            	}
            }
          });
          return isPasswordSet;
        }
    };
    //end: lookup actions
    
    //start: resetting sections based on user actions and ajax responses
    var reset = {
    	email : function() {
    		commonFunctionality.hideError();
    		isViaEmail = true;
    		$('.otp-message').hide();
    		$('.signup-welcome').hide();
    		$('.login-welcome').show();
    		reset.passwordActions('hide', '');
    		reset.loginActions('show', 'login');
    		$('.mobile-login').hide();
    		$('.login-via-otp-email').show();
    		$('.email-login').show();
    		//$('.signup').show();
    		$rememberMe.show();
    	},
    	mobileNumber: function() {
    		commonFunctionality.hideError();
    		isViaMobileNumber = true;
    		$('.otp-message').hide();
    		$('.signup-welcome').hide();
    		$('.login-welcome').show();
    		reset.passwordActions('hide', '');
    		reset.loginActions('show', 'next');
    		$('.email-login').hide();
    		$rememberMe.hide();
    		$('.otp').hide();
    		$('.login-via-otp-email').show();
    		//$('.signup').show();
    		$('.mobile-login').show();
    		$('.mobile-number').show();
    	},
    	mobileOTP: function() {
    		commonFunctionality.hideError();
    		$('.otp-message').hide();
    		$('.signup-welcome').hide();
    		$('.login-welcome').show();
    		//$('.signup').hide();
    		reset.passwordActions('hide', '');
    		reset.loginActions('show', 'back,login');
    		$('.mobile-number').hide();
    		$('.login-via-otp-email').show();
    		$('.otp').show();
    		$rememberMe.show();
    	},
    	signup: function() {
    		commonFunctionality.hideError();
    		isViaEmail = true;
    		$('.otp-message').hide();
    		$('.login-welcome').hide();
    		$('.signup-welcome').show();
    		reset.passwordActions('hide', '');
    		reset.loginActions('show', 'next');
    		//$('.signup').hide();
    		$('.email-login').hide();
    		$('.login-via-otp-email').hide();
    		$rememberMe.hide();
    		$('.otp').hide();
    		$('.mobile-login').show();
    		$('.mobile-number').show();
    	},
    	passwordActions: function (_action, _class) {
    		if (_action == 'show') {
    			$('.login-via-otp-email').hide();
    			$rememberMe.hide();
    			$('#resend-otp').hide();
	    		$('.password-actions').show();
	            $('.password-actions a').hide();
	            $('.password-actions a.' + _class).show();
    		} else if (_action == 'hide') {
    			$('.password-actions').hide();
    		}
    	},
    	loginActions: function (_action, _classes) {
    		if (_action == 'show') {
    			$('.login-actions').show();
        		$('.login-actions input').hide();
        		var _classList = _classes.split(",");
        		_classList.forEach(function(_classItem) {
        			$('.login-actions .' + _classItem).show();
        		});
    		} else if (_action == 'hide') {
    			$('.login-actions').hide();
    		}
    	}
    };
    //end: resetting sections based on user actions and ajax responses
    
    //start: toggle login via email or mobile number
    $(document).on('click', '.login-via-otp-email span', function () {
      if (isViaEmail) {
    	  reset.mobileNumber();
    	  isViaEmail = false;
    	  isViaMobileNumber = true;
      } else if (isViaMobileNumber) {
    	  reset.email();
    	  isViaMobileNumber = false;
    	  isViaEmail = true;
      }
      //isViaEmail = (isViaEmail == true ? false : true);
      //isViaMobileNumber = (isViaMobileNumber == true ? false : true);
    });
    
    //end: toggle login via email or mobile number

    //start: login via email
    $emailPassword.keydown(function () {
      commonFunctionality.passwordEyeKey($(this), $('#regi-eye'));
    });

    $(document).on('click', '#regi-eye', function () {
      commonFunctionality.passwordShowHide($emailPassword, $('#regi-eye'));
    });
    
    //end: login via email

    
    //start: login via mobile number
    $(document).on('click', '#resend-otp', function () {
      otp.send();
      isResendRequested = true;
    });
    
    //end: login via mobile number

    //start: login actions
    $(document).on('click', '.next', function () {
    	isViaLogin = false;
    	if (isViaSignup && isOrgNotRegUser && validate.email(isViaLogin) && validate.mobile(isViaLogin) && lookup.mobile()) {
    		$('#register').trigger('submit');
        } else if (isViaMobileNumber && validate.mobile(isViaLogin) && lookup.mobile() && lookup.maskedEmail()) {
        	$maskedMobilenumber.text("+" + mobileNumberWithCode);
        	otp.send();
        	reset.mobileOTP();
        }
    });
    
    $(document).on('click', '.back', function() {
    	isViaLogin = false;
    	if (isViaMobileNumber) {
    		reset.loginActions('show', 'next');
    		$('.mobile-number').show();
    		$('.otp-message').hide();
    		$('.otp').hide();
    	}
    });
    
    $(document).on('click', '#login', function (event) {
        event.preventDefault();
        isViaLogin = true;
        if (isViaEmail && validate.email(isViaLogin) && lookup.orgEmail($emailId) && lookup.email($emailId)) {
      		$('#loginForm').trigger('submit');
        } else if (isViaMobileNumber && validate.mobile(isViaLogin)) {
      	  	$('#loginForm').trigger('submit');
        }
      });
    
    //end: login actions
    
    //start: password actions
    $(document).on('click', '.login-with-password', function() {
    	reset.email();
    });
    //end: password actions
    
    //start: top info icon
    $(document).on('click', '.info-icon-toggle', function () {
      $('.top-info-text-desc').toggleClass('d-none');
      $('.info-icon').toggleClass('rotated');
    });
    //end: top info icon
    
    //start: button actions on clicking 'enter'
	$('form.email-mobile-login').submit(function() {
		event.preventDefault();
		if ($('.next').is(':visible')) {
			$('.next').trigger('click');
		} else if ($('.login').is(':visible')) {
			$('.login').trigger('click');
		}
	});
    
	function triggerAction() {
		$('form.email-mobile-login').trigger('submit');
	} 	
    //end: button actions on clicking 'enter'
    /*$(document).on('click', '#send-login-link', function () {
      $('#loader-overlay').removeClass('d-none');
      $(".errorMsg").html('');
      var xhr = $.get(context + "autologin?email=" + encodeURIComponent($('#email').val().toLowerCase()));
      xhr.done(function () {
        $('.selected-email').text($('#email').val().toLowerCase());
        $('.link-sent-msg-wrapper').removeClass('d-none');
        $('.flow-wrapper').addClass('d-none');
        $('#loader-overlay').addClass('d-none');
      });
      xhr.fail(function (error) {
        if (error.status === 409)
          window.location.href = "/invest";
        else {
          $('#loader-overlay').addClass('d-none');
          $(".errorMsg").html("Link sending failed, please try again.").removeClass("d-none");
        }
      });
    });
    
    $(document).on('click', '.resen-link', function () {
      $('#loader-overlay').removeClass('d-none');
      $(".errorMsg").html('');
      var xhr = $.get(context + "autologin?email=" + encodeURIComponent($('#email').val()));
      xhr.done(function (response) {
        $('.msg-header span').text('re-sent');
        $('#loader-overlay').addClass('d-none');
      });
      xhr.fail(function (error) {
        $('#loader-overlay').addClass('d-none');
        $(".errorMsg").html("Link sending failed, please try again.").removeClass("d-none");
      });
    });

    $(document).on('click', '.change-link', function () {
      location.reload();
    });*/
	featuredVariables.flipDataPoints();
  };
  return {
    init: init
  };
})()