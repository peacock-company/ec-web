package in.rasada.ec.infra.config;

import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

//@Component
public class SiteSessionListener { //implements HttpSessionListener {

    private static final Logger LOG = LoggerFactory.getLogger(SiteSessionListener.class);
    
//    @Override
//    public void sessionCreated(HttpSessionEvent se) {
//        HttpSessionListener.super.sessionCreated(se);
//        LOG.debug("HTTP Session created: {}", se.getSession().getId());
//    }
//    
//    @Override
//    public void sessionDestroyed(HttpSessionEvent se) {
//        HttpSessionListener.super.sessionDestroyed(se);
//        LOG.debug("HTTP Session destroyed: {}", se.getSession().getId());
//    }
    
}
