package in.rasada.ec.infra.config;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.SimpleUrlAuthenticationFailureHandler;

/**
 * Using a custom handler, because of the issue of invalid credentials for login via ajax in some page 
 * What we'd like is to send 401 status code in such cases. For other cases, we'll let it
 * send back to dedault /login?error.
 */
class CustomAuthenticationFailureHandler extends SimpleUrlAuthenticationFailureHandler {

    private static final Logger LOG = LoggerFactory.getLogger(CustomAuthenticationFailureHandler.class);


    public CustomAuthenticationFailureHandler() {
        super();
    }


    public CustomAuthenticationFailureHandler(String defaultFailureUrl) {
        super(defaultFailureUrl);
    }


    @Override
    public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response, AuthenticationException exception) 
            throws IOException, ServletException {
        LOG.debug("inside onAuthenticationFailure...");

        super.onAuthenticationFailure(request, response, exception);

    }
}
