package in.rasada.ec.domain;

import java.util.ArrayList;
import java.util.List;

public class MessageResponse {

    private List<MessageBean> messages = new ArrayList<>();

    public MessageResponse() {
    }

    public MessageResponse(MessageBean message) {
        this();
        this.messages.add(message);
    }
    
    @Override
    public String toString() {
        return messages.toString();
    }
    
    public List<MessageBean> getMessages() {
        return messages;
    }

    public void setMessages(List<MessageBean> messages) {
        this.messages = messages;
    }

    public void addMessage(MessageBean message) {
        this.messages.add(message);
    }
    

}
