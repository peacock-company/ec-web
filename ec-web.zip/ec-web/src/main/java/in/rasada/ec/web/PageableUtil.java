package in.rasada.ec.web;

import java.util.Iterator;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class PageableUtil {
	
	private static final Logger LOG = LoggerFactory.getLogger(PageableUtil.class);
	
    //==================================================================================================================
    /**
     * Generates a URL parameter string consisting of pagination and  sorting parameters e.g. 
     * "page=0&size=1&sort=name;asc". See CatalogControllerUtilTest for detailed examples.
     * 
     * @param page
     * @param size
     * @param sortList
     * @return
     */
    public String pagingAndSortingParams(Integer page, Integer size, List<String> sortList) {
        StringBuilder params = new StringBuilder("");
        if (page != null) {
            params.append("page=").append(page);
        }
        if (size != null) {
            if (params.length() > 0) {
                params.append("&");
            }
            params.append("size=").append(size);
        }
        if (sortList != null && !sortList.isEmpty()) {
            if (params.length() > 0) {
                params.append("&");
            }
            params.append(sortingParams(sortList));
        }
        String p = params.toString();
        LOG.debug("pagingAndSortingParams() for '{}', '{}', '{}' returned: {}", page, size, sortList, p);
        return p;
    }

    //==================================================================================================================
    private String sortingParams(List<String> sortList) {
        StringBuilder params = new StringBuilder("");
        if (sortList != null && !sortList.isEmpty()) {
            for (Iterator<String> it = sortList.iterator(); it.hasNext();) {
                String sortBy = it.next();
                sortBy = sortBy.replace(";", ",");
                params.append("sort=").append(sortBy);
                if (it.hasNext()) {
                    params.append("&");
                }
            }
        }
        if (!sortList.contains("id") && !sortList.contains("id;asc") && !sortList.contains("id;desc")) {
            params.append("&sort=id");
        }
        String p = params.toString();
        LOG.debug("sortingParams() for '{}' returned: {}", sortList, p);
        return p;
    }
    
}
