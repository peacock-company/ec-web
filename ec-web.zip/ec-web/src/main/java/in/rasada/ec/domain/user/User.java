package in.rasada.ec.domain.user;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;

import in.rasada.ec.domain.valueobject.Image;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class User implements Serializable {
    
    private static final long serialVersionUID = 1L;

    public static final int DAYS_FOR_FIRST_PROFILE_UPDATE_PROMPT = 7;
    public static final int DAYS_FOR_SECOND_PROFILE_UPDATE_PROMPT = 14;

    public enum OnboardingStatus {NONE, NAME, LANGUAGES, LANG_SKIP_PROF_NO, LANG_SKIP_PROF_SKIP, LANG_SKIP_PROF_YES, LANG_YES_PROF_SKIP, PROFESSIONS, COMPLETE};
    public enum ResidentialStatus {RI, NRI, OCI};
    public enum MigrateCreditChoice {NA, NOT_CHOSEN, MIGRATE, DONT_MIGRATE, D2I};
    public enum ProfilePrivacy {PUBLIC, SEMIPRIVATE, PRIVATE};
    public enum Gender {M, F, TG};

    
    private Long id;
    private String username;
    private String password;
    private String firstName;
    private String lastName;
    private String mobileNumber;
    private Set<Role> roles = new HashSet<Role>();
    private OnboardingStatus onboardingStatus = OnboardingStatus.NONE;
    private Date subscriptionLastSkipped;
    private ResidentialStatus residentialStatus = ResidentialStatus.RI;
    private MigrateCreditChoice migrateCreditChoice = MigrateCreditChoice.NA;
    private int migrateCreditChoiceSkipCounter;
    private BigDecimal rangdeCredit = BigDecimal.ZERO;
    private BigDecimal miscCreditAmount = BigDecimal.ZERO;
    private BigDecimal repaymentCreditAmount = BigDecimal.ZERO;
    private String friendlyKey;
    private String profileKey;
    private String kycStatus;
    private Boolean passwordSet;
 
 // new "settings" fields - Dec 2019
    private Image profilePicture;
    private String city;
    private String locationState;
    private String designation;
    private String company;
    private String website;
    private String interests;
    private String whyBelieve;
    private String vision;
    private String linkedin;
    private String facebook;
    private String twitter;
    private String instagram;
    private ProfilePrivacy profilePrivacy = ProfilePrivacy.SEMIPRIVATE;
    private int profileUpdatePromptCounter = 0;
    private Date created;
    
    public Long partnerId;
    private Gender gender;
    @Override
    public String toString() {
        return id + "-" + firstName + "-" + lastName;
    }
    
    public String getFullName() {
        return firstName + " " + lastName;
    }
    
    public boolean hasMissingProfileFields() {
        return 
                profilePicture == null
                ||
                StringUtils.isBlank(designation)
                ||
                StringUtils.isBlank(company)
                ||
                StringUtils.isBlank(interests)
                ||
                StringUtils.isBlank(vision)
                ||
                StringUtils.isBlank(whyBelieve)
                ||
                StringUtils.isBlank(linkedin)
                ||
                StringUtils.isBlank(facebook)
                ||
                StringUtils.isBlank(twitter)
                ||
                StringUtils.isBlank(instagram)
                ;
    }
    
    public void incrementProfileUpdatePrompts() {
        profileUpdatePromptCounter = profileUpdatePromptCounter + 1;
    }
}
