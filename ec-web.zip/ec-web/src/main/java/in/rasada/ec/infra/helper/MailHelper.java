package in.rasada.ec.infra.helper;

import java.util.List;

import org.springframework.scheduling.annotation.Async;
import org.thymeleaf.context.Context;

public interface MailHelper {
    
    public static final String RASADA_CONTACT_MAIL = "contact@rasadatechnologies.com";
    public static final String VENKATESH_MAIL = "venkatesh@rasadatechnologies.com";
    
    void sendMail(String to, String subject, String htmlTemplate, Context context);
    
    @Async void sendMailAsync(String to, String subject, String htmlTemplate, Context context);

    void sendMail(String to, String subject, String htmlTemplate, Context context, MailAttachment attachment);
    
    void sendMail(String to, String bcc, String subject, String htmlTemplate, Context context, MailAttachment attachment);
    
    void sendMail(String to, String bcc, String subject, String htmlTemplate, Context context);

    void sendMail(String to, String subject, String htmlTemplate, Context context, List<MailAttachment> attachments);

    void sendMailFromVenkatesh(String to, String subject, String htmlTemplate, Context context);

}
