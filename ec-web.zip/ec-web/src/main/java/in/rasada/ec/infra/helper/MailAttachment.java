package in.rasada.ec.infra.helper;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public class MailAttachment {

    private String fileName;
    private byte[] inputStreamSource;

}
