package in.rasada.ec.infra.config;

import static org.springframework.http.HttpMethod.GET;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.access.AccessDeniedHandlerImpl;
import org.springframework.security.web.access.DelegatingAccessDeniedHandler;
import org.springframework.security.web.authentication.session.ChangeSessionIdAuthenticationStrategy;
import org.springframework.security.web.authentication.session.CompositeSessionAuthenticationStrategy;
import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.security.web.context.SecurityContextRepository;
import org.springframework.security.web.csrf.CsrfAuthenticationStrategy;
import org.springframework.security.web.csrf.CsrfException;
import org.springframework.security.web.csrf.HttpSessionCsrfTokenRepository;



@Configuration
// WARNING: using lombok annotation for construction did not seem to work for this bean
public class SiteSecurityConfig extends WebSecurityConfigurerAdapter {
    
    public static final String HOME_URL = "/home";
    public static final String LOGIN_URL = "/login";
    public static final String LOGIN_FAILURE_URL = "/login?error";
    public static final String LOGOUT_POST_URL = "/logout";
    public static final int REMEMBER_ME_COOKIE_VALIDITY_SECONDS = 7 * 24 * 60 * 60; // 7 days
//    public static final int REMEMBER_ME_COOKIE_VALIDITY_SECONDS = 1 * 60 * 60; // 1 hour, for testing purposes

//    private UserDetailsService userDetailsService;
//    private AuthenticationProvider authProvider;
    
//    @Autowired
//    public SiteSecurityConfig(UserDetailsService userDetailsService, AuthenticationProvider authenticationProvider
//            ) {
//        super();
//        this.userDetailsService = userDetailsService;
//        this.authProvider = authenticationProvider;
//    }

//    @Autowired
//    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
//        auth
//        .userDetailsService(userDetailsService)
//        ;
//    }
    
    @Override
    public void configure(WebSecurity web) throws Exception {
        web.ignoring()
            .antMatchers("/static/**") // static resources like .jpg, .css
            .antMatchers("/robots.txt")
            .antMatchers("/sitemap.xml")
            ;
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
            .authorizeRequests()
                .antMatchers(LOGIN_URL).permitAll()
                .antMatchers(GET, "/").permitAll()
                .anyRequest().permitAll()
                .and()

                .formLogin()
                .loginPage(LOGIN_URL)
                .permitAll()
//                .successHandler(siteSavedRequestAuthenticationSuccessHandler)
//                .defaultSuccessUrl(LOAN_LISTING_URL)
                .failureHandler(new CustomAuthenticationFailureHandler(LOGIN_FAILURE_URL))
                .and()
            .logout()
                .permitAll()
//                .addLogoutHandler(siteLogoutHandler)
//                .logoutSuccessUrl()
                .and()
//            .exceptionHandling()
//                .accessDeniedHandler(customAccessDeniedHandler())
//                .and()
            // SecurityContextPersistenceFilter is among the first Spring Security filters to be called, and we want
            // our ClientRequestAttributesFilter to fire before them. this is because sometimes spring Sec hijacks the
            // chain e.g. after successful authentication, and we still want our filter to fire in those cases
//            .sessionManagement()
//            	.sessionCreationPolicy(SessionCreationPolicy.ALWAYS)
//            	.sessionFixation().migrateSession()
//            	.and()
//            .securityContext()
//                .securityContextRepository(httpSessionSecurityContextRepository())
            ;
    }

    /** Exposing HttpSessionSecurityContextRepository as a bean only because we had to do some direct invocations in UserController. */
//    @Bean
//    public SecurityContextRepository httpSessionSecurityContextRepository() {
//        return new HttpSessionSecurityContextRepository();
//    }

    /** 
     * Overriding this because we only want our 1 provider to be used. Else it would use ours as well as 
     * DaoAuthenticationProvider.
     */
//    @Bean
//    @Override
//    protected AuthenticationManager authenticationManager() throws Exception {
//        List<AuthenticationProvider> providers = new ArrayList<>();
//        providers.add(authProvider);
//        return new ProviderManager(providers);
//    }
    
    /** Exposing this as a bean, because we need it in Registration to automatically log the user in. */
//    @Bean
//    SessionAuthenticationStrategy p2pSessionAuthenticationStrategy() {
//        List<SessionAuthenticationStrategy> delegateStrategies = new ArrayList<>();
//        delegateStrategies.add(new ChangeSessionIdAuthenticationStrategy());
//        delegateStrategies.add(new CsrfAuthenticationStrategy(new HttpSessionCsrfTokenRepository()));
//        CompositeSessionAuthenticationStrategy strat = new CompositeSessionAuthenticationStrategy(delegateStrategies);
//        return strat;
//    }
    
//    @Bean
//    AccessDeniedHandler customAccessDeniedHandler() {
//        LinkedHashMap<Class<? extends AccessDeniedException>, AccessDeniedHandler> handlers = new LinkedHashMap<>();
//        handlers.put(CsrfException.class, new CustomAccessDeniedHandlerImpl());
//        return new DelegatingAccessDeniedHandler(handlers, new AccessDeniedHandlerImpl());
//    }

}











