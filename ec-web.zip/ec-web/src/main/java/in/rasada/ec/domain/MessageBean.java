package in.rasada.ec.domain;

import java.io.Serializable;

public class MessageBean implements Serializable {
    
    private static final long serialVersionUID = 1L;

    public static enum MessageType {ERROR, WARN, ALERT, INFO};

    private MessageType type;
    private String code;
    private String message;
    
    public static MessageBean error(String code, String message) {
        return new MessageBean(MessageType.ERROR, code, message);
    }
    
    public static MessageBean warn(String code, String message) {
        return new MessageBean(MessageType.WARN, code, message);
    }
    
    public static MessageBean alert(String code, String message) {
        return new MessageBean(MessageType.ALERT, code, message);
    }
    
    public static MessageBean info(String code, String message) {
        return new MessageBean(MessageType.INFO, code, message);
    }
    
    private MessageBean(MessageType type, String code, String message) {
        this.type = type;
        this.code = code;
        this.message = message;
    }

//    private MessageBean(String message) {
//        this(MessageType.ERROR, "", message);
//    }
    
	  public MessageBean() {
	  }
    
    @Override
    public String toString() {
        return new StringBuilder()
                .append(type).append("-")
                .append(code).append("-")
                .append(message)
                .toString();
    }
    
    public String getCode() {
        return code;
    }
    public void setCode(String code) {
        this.code = code;
    }
    public String getMessage() {
        return message;
    }
    public void setMessage(String message) {
        this.message = message;
    }
    public MessageType getType() {
        return type;
    }

}
