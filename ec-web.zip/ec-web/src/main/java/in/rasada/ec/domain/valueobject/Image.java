package in.rasada.ec.domain.valueobject;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Image implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private String uri;
    private String uriLarge;
    private String uriMedium;
    private String uriSmall;
    private String uriFace;
    private String caption;
    private String altText;
    
    private String uriFull;

    @Override
    public String toString() {
        return uri;
    }

    @Override
    public boolean equals(Object obj) {
        Image other = (Image) obj;
        return uri.equals(other.getUri());
    }

    @Override
    public int hashCode() {
        return uri.hashCode();
    }

}
