package in.rasada.ec.infra.config;

import static in.rasada.ec.infra.config.SiteSecurityConfig.LOGIN_URL;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.access.AccessDeniedHandlerImpl;

/**
 * Using a custom handler, because of the issue of a POST after session expiry - the CsrfFilter sees a bad CSRF token,
 * and so returns a 403. What we'd like is to redirect to the login page in such cases. For other cases, we'll let it
 * send back a 403.
 */
class CustomAccessDeniedHandlerImpl extends AccessDeniedHandlerImpl {
    
    private static final Logger LOG = LoggerFactory.getLogger(CustomAccessDeniedHandlerImpl.class);

    @Override
    public void handle(
            HttpServletRequest request,
            HttpServletResponse response,
            AccessDeniedException accessDeniedException) throws IOException, ServletException {
        LOG.warn("CsrfException in custom AccessDeniedHandler:", accessDeniedException);
        Authentication authentication = (Authentication) SecurityContextHolder.getContext().getAuthentication();
        LOG.debug("authentication: {}", authentication);
        String requestedWith = request.getHeader("X-Requested-With");
        LOG.debug("requestedWith: {}", requestedWith);

        // redirect to login if there's no authenticated user - e.g. after session expiry
        if (authentication == null || authentication instanceof AnonymousAuthenticationToken) {
            // see https://docs.spring.io/spring-security/site/docs/current/reference/htmlsingle/#servletapi-logout
            request.logout();
            // String pathInfo = request.getPathInfo();
            // LOG.debug("pathInfo: {}", pathInfo);
            // String requestURI = request.getRequestURI();
            // LOG.debug("requestURI: {}", requestURI);
            // String servletPath = request.getServletPath();
            // LOG.debug("servletPath: {}", servletPath);
            String contextPath = request.getContextPath();
            LOG.debug("contextPath: {}", contextPath);
            String loginURI = contextPath + LOGIN_URL;

                response.sendRedirect(loginURI);

        } else {
            super.handle(request, response, accessDeniedException);
        }
    }
}
