package in.rasada.ec.utils;

import java.util.Locale;

import com.ibm.icu.number.LocalizedNumberFormatter;
import com.ibm.icu.number.NumberFormatter;
import com.ibm.icu.number.NumberFormatter.GroupingStrategy;
import com.ibm.icu.number.Precision;

public class MoneyUtil {

    public static final LocalizedNumberFormatter RUPEE_FORMATTER = NumberFormatter
            .withLocale(new Locale("en", "IN"))
            .grouping(GroupingStrategy.ON_ALIGNED)
            .precision(Precision.maxFraction(2))
            ;
 
    public static final LocalizedNumberFormatter RUPEE_PAISE_FORMATTER = NumberFormatter
            .withLocale(new Locale("en", "IN"))
            .grouping(GroupingStrategy.ON_ALIGNED)
            .precision(Precision.fixedFraction(2));
            ;

    public static final LocalizedNumberFormatter PERCENTAGE_FORMATTER = NumberFormatter
            .withLocale(new Locale("en", "IN"))
            .precision(Precision.maxFraction(2))
            ;

}
