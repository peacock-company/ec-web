package in.rasada.ec.web.product;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import in.rasada.ec.web.PageableUtil;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Controller
@RequestMapping("/feedme/recipes")
@RequiredArgsConstructor(onConstructor_={@Autowired})
public class RecipesListingController {

    private static final Logger LOG = LoggerFactory.getLogger(RecipesListingController.class);
    private static final String KEYWORD_AND = "&";
    
    private @NonNull PageableUtil pageableUtil;
    

    @GetMapping()
    public String getAllRecipies(Model model,
            HttpServletRequest request) {
    	
        return "product/feedme-listing";
    }
    
    
}
