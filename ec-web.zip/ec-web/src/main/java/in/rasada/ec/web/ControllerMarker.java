package in.rasada.ec.web;

import in.rasada.ec.infra.config.WebConfig;

/**
 * Marker class used to identify the root package of all the app's Controller classes.
 * @see WebConfig
 */
public class ControllerMarker {

}
