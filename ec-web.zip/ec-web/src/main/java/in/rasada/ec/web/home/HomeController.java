package in.rasada.ec.web.home;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.thymeleaf.context.Context;

import in.rasada.ec.infra.helper.MailHelper;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Controller
@RequestMapping("/")
@RequiredArgsConstructor(onConstructor_={@Autowired})
public class HomeController {
    
    private @NonNull MailHelper mailHelper;
    
    private static final Logger LOG = LoggerFactory.getLogger(HomeController.class);
    
    private static final String HOME_PAGE_VIEW_NAME = "home/index";

    @GetMapping(value = {"home",""})
    public String displayHomePage(Model model) {
        return HOME_PAGE_VIEW_NAME;
    }
    
    @GetMapping(value = {"about"})
    public String aboutPage(Model model) {
        return "home/about";
    }
    
    @GetMapping(value = {"home","contact"})
    public String contactPage(Model model) {
        return "home/contact";
    }
    
    @PostMapping(value="/service-request")
    public ResponseEntity<?> postServiceRequest(
            @RequestParam String name, @RequestParam String email,
            @RequestParam String subject, @RequestParam String message) {
        
        LOG.debug("postServiceRequest called with params name: {}, email: {}, subject: {}, message: {}", 
                name, email, subject, message);
        
        Context context = new Context();
        context.setVariable("firstName", name);
        context.setVariable("email", email);
        context.setVariable("subject", subject);
        context.setVariable("message", message);
        
        String subjectToUser = "Your service request received";
        String templateToUser = "email/service-request";
        String emailToUser = email;
        
        String subjectToTeam = "New service request received";
        String templateToTeam = "email/service-request-team";
        
        try {
            mailHelper.sendMail(emailToUser, subjectToUser, templateToUser, context);
            LOG.debug("service requerst mail sent successfully...");
            
            mailHelper.sendMail(MailHelper.RASADA_CONTACT_MAIL, subjectToTeam, templateToTeam, context);
            return ResponseEntity.ok(null);
            
        } catch (Exception e) {
            LOG.error("mail failed..", e);
        }
        
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Something went wrong!!!");
        
    }

}
