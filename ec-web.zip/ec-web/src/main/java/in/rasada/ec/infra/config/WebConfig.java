package in.rasada.ec.infra.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.ConversionService;
import org.springframework.core.serializer.support.DeserializingConverter;
import org.springframework.core.serializer.support.SerializingConverter;
import org.springframework.format.support.DefaultFormattingConversionService;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.thymeleaf.extras.springsecurity4.dialect.SpringSecurityDialect;

//import com.zaxxer.hikari.HikariDataSource;

import nz.net.ultraq.thymeleaf.LayoutDialect;

@Configuration
public class WebConfig implements WebMvcConfigurer {
    private static final Logger LOG = LoggerFactory.getLogger(WebConfig.class);
    // to add the thymeleaf layout and security dialects. We only need to define the beans, Spring Boot will do the rest
    @Bean
    public SpringSecurityDialect springSecurityDialect() {
        return new SpringSecurityDialect();
    }
    @Bean
    public LayoutDialect springLayoutDialect() {
        return new LayoutDialect();
    }
    /**
     * For formatting amount fields etc. 
     */
    @Bean
    public ConversionService conversionService() {
        DefaultFormattingConversionService conversionService = new DefaultFormattingConversionService();
//      conversionService.addConverter(String.class, String[].class,
//              new Converter<String, String[]>() {
//                  @Override
//                  public String[] convert(String source) {
//                      return StringUtils.delimitedListToStringArray(source, ";");
//                  }
//              });
        
        // required by Spring Session's JdbcOperationsSessionRepository (code is copied from that class)
        // see https://github.com/spring-projects/spring-session/issues/556
        conversionService.addConverter(Object.class, byte[].class, new SerializingConverter());
        conversionService.addConverter(byte[].class, Object.class, new DeserializingConverter());

        return conversionService;
    }

//    @Bean
//    @ConfigurationProperties("site.session.datasource")
//    public HikariDataSource siteSessionDataSource() {
//        return DataSourceBuilder.create().type(HikariDataSource.class).build();
//    }
    
}
