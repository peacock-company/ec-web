package in.rasada.ec.domain.valueobject;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Video {
	
    private String uri;
    private String thumbnail_uri;
    private String caption;
    private String altText;
    
    @Override
    public String toString() {
        return uri;
    }
    
    @Override
    public boolean equals(Object obj) {
    	Video other = (Video) obj;
    	return uri.equals(other.getUri());
    }
    
    @Override
    public int hashCode() {
    	return uri.hashCode();
    }

}
