package in.rasada.ec.domain.cart;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import in.rasada.ec.domain.MessageBean;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CartRepresentation {

	public static BigDecimal PAYMENT_GATEWAY_PERCENT = new BigDecimal("2");
	
	public static enum Status {
        OPN,  // Open
        ABD,  // Abandoned
        CPL,   // Completed
        RTD   // Retired
    };
    
    private Set<CartItemRepresentation> items = new HashSet<>();
    
    private Boolean isGatewayChargeIncluded = Boolean.FALSE;
    
    private Boolean isProcessingFeeIncluded = Boolean.FALSE;
    
    private Status status = Status.OPN;
    
    private List<MessageBean> messages = new ArrayList<>();
    
    private BigDecimal rangdeCredit = BigDecimal.ZERO;
    
    private int count;
    
    public BigDecimal daysOfLivelihoodGenerated;
    
    private Boolean isSubscriptionSkipped = Boolean.FALSE;

    private Boolean containsTEPLoan = Boolean.FALSE;
    
    private Map<String, Object> itemsByState;
    
    private BigDecimal availableRangdeCredit = BigDecimal.ZERO;
    
    private BigDecimal committedCredit = BigDecimal.ZERO;
    
    public BigDecimal processingFee;
    
    public BigDecimal itemsAmount;
    
    public BigDecimal totalAmount;
    
    private String ifsc;
    
    private String bankName;

    private String accountNumber;
    
//    public BigDecimal getItemsAmount() {
//        return items.stream().filter(ci -> ci.getStatus() == CartItemRepresentation.Status.ACTIVE).map(CartItemRepresentation::getAmountInvested).reduce(BigDecimal.ZERO, BigDecimal::add);
//    }
//    
//    public BigDecimal getPaymentGatewayAmount() {
//    	BigDecimal result = BigDecimal.ZERO;
//        if (isGatewayChargeIncluded) {
//            result = getItemsAmount().multiply(PAYMENT_GATEWAY_PERCENT).divide(BigDecimal.valueOf(100));
//        }
//        return result;
//    }
//    
//    public BigDecimal getTotalAmount() {
//        return getItemsAmount().add(getPaymentGatewayAmount());
//    }

    public void addItem(CartItemRepresentation cartItemRep) {
        items.add(cartItemRep);
    }
    
    @Override
    public String toString() {
        return status + "-" + items + "-" + messages;
    }
    
	
}
