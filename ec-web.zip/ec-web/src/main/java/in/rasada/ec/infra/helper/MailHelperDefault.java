package in.rasada.ec.infra.helper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

@Component
@Primary
public class MailHelperDefault extends AbstractMailHelper {

    private JavaMailSender mailSender;

    @Autowired
    public MailHelperDefault(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    @Override
    JavaMailSender getMailSender() {
        return mailSender;
    }

}
