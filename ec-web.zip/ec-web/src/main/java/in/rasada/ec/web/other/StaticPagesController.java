package in.rasada.ec.web.other;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class StaticPagesController {

    @GetMapping("/feedme")
    public String feedMeHome() {
        return "feedme/home";
    }

}
