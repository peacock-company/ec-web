package in.rasada.ec.domain.cart;

import java.math.BigDecimal;

import in.rasada.ec.domain.valueobject.Image;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CartItemRepresentation {

    public enum Status {
        ACTIVE, INACTIVE
    };
    
    private BigDecimal amountInvested = BigDecimal.ZERO;

    private String loanCode;
    
    private BigDecimal loanTotalAmount = BigDecimal.ZERO;
    
    private BigDecimal loanAmountRaised = BigDecimal.ZERO;
    
    private String borrowerName;
    private String borrowerFriendlyKey;
    
    private Image avatar;
    
    private String borrowerOccupation;
    
    private Boolean isPartiallyRaised = Boolean.FALSE;
    
    private int covered;
    
    private int timeRemaining;
    
    private String regionName;
    
    private String archetypeTag;
    private String archetype;
    
    private Status status = Status.ACTIVE;

    public CartItemRepresentation() {
        
    }
    
    public CartItemRepresentation(CartRepresentation cartRep, String loanCode, BigDecimal amount) {
        this.loanCode = loanCode;
        this.amountInvested = amount;
        if (cartRep != null) {
            cartRep.addItem(this);
        }
    }
    
    @Override
    public boolean equals(Object obj) {
        return loanCode.equals(((CartItemRepresentation) obj).getLoanCode());
    }
    
    @Override
    public int hashCode() {
        return loanCode.hashCode();
    }
    
    @Override
    public String toString() {
        return loanCode + "-" + borrowerName + "-" + amountInvested.toPlainString();
    }

    public BigDecimal getAmountNeeded() {
        return loanTotalAmount.subtract(loanAmountRaised);
    }


}
